import java.util.Arrays;

public class SortExample {
    public static void main(String[] args) {
        int[] numbers = {3, 5, 2, 9, 1};
        Arrays.sort(numbers);
        System.out.println("Sorted array: " + Arrays.toString(numbers));
    }
}
